window.SUPERDB_CONFIG = {
  mode: "superdb",
  url: "https://xahfaaefnuhpoeyanbxw.supabase.co",
  anonKey: "PEGAR_AQUI_TU_SUPABASE_ANON_KEY",
  adminUsername: "admin",
  adminEmail: "admin@oatec.local",
  storagePrefix: "oatec-itba-2026"
};
